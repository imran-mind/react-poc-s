import { useEffect, useState } from 'react';
import './App.css';
import useWindowScrollPosition from './useWindowScrollPosition';

function App() {
  const [data,setData] = useState([]);
  const [isLoaded,setIsLoading] = useState(true);

  useWindowScrollPosition('App_Comp_Scroll_Y', !isLoaded);

  const fetchData = async () => {
    try {
        const data = await fetch('https://reqres.in/api/users');
        const json = await data.json();
        console.log(json.data)
        setData(json.data);
        setIsLoading(false);
    } catch (error) {
        console.log(error);
        setIsLoading(false);
    }
  };
  
  useEffect(()=>{
    if (data.length === 0) {
      fetchData();
    }
  },[]);

  function goToTop(){
    console.log('goto')
    window.scrollTo({top: 0, behavior: 'smooth'});
  }


  function renderPara(data){
    return <div key={data.id}>
       <img src="https://i.picsum.photos/id/996/200/300.jpg?hmac=vjpTROwvLRamauR7RHTF21dxsN351pnM44SxoByue5c" alt="Girl in a jacket" width="500" height="600"/>
      <h1>{data.id}</h1>
      <h1>{data.email}</h1>
      <h1>{data.first_name}</h1>
      <h1>{data.last_name}</h1>
    </div>
  }

  
  return (
    <div className="App">
      <h1>Hello</h1>
      {
        data.map((item)=>{
          return renderPara(item);
        })
      }
      <button className="go-to-top" onClick={()=>goToTop()}>Go Top</button>
    </div>
  );
}

export default App;
