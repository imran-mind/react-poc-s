import { createSlice, createAction } from '@reduxjs/toolkit'
import { createStore, combineReducers } from 'redux'

const incrementBy = createAction('incrementBy')
const decrementBy = createAction('decrementBy')

const counterSlice = createSlice({
  name: 'counter',
  initialState: {counter:0},
  reducers: {
    increment: (state,action)=>{
        state.counter = state.counter + 1;
    },
    decrement: (state,action)=>{
        state.counter = state.counter - 1;
    },
    multiply: {
      reducer: (state, action) => state * action.payload,
      prepare: (value) => ({ payload: value || 2 }), // fallback if the payload is a falsy value
    },
  },
  // "builder callback API", recommended for TypeScript users
  extraReducers: (builder) => {
    builder.addCase(incrementBy, (state, action) => {
      return state + action.payload
    })
    builder.addCase(decrementBy, (state, action) => {
      return state - action.payload
    })
  },
})

const userSlice = createSlice({
  name: 'user',
  initialState: { name: 'imran', age: 20 },
  reducers: {
    setUserName: (state, action) => {
      state.name = action.payload // mutate the state all you want with immer
    },
  },
  // "map object API"
  extraReducers: {
       /* action will be inferred as "any", as the map notation does not contain type information */
    [counterSlice.actions.increment]: (state,action) => {
      state.age += 1
    },
    [counterSlice.actions.decrement]: (state,action) => {
        state.age -= 1
      }
  },
})

const reducer = combineReducers({
    counterSlice: counterSlice.reducer,
    userSlice: userSlice.reducer,
})

const store = createStore(reducer);

export default store;
export const { name, actions } = counterSlice;

export const { increment,decrement,multiply } = actions;
// store.dispatch(counter.actions.increment())
// // -> { counter: 1, user: {name : '', age: 21} }
// store.dispatch(counter.actions.increment())
// // -> { counter: 2, user: {name: '', age: 22} }
// store.dispatch(counter.actions.multiply(3))
// // -> { counter: 6, user: {name: '', age: 22} }
// store.dispatch(counter.actions.multiply())
// // -> { counter: 12, user: {name: '', age: 22} }
// console.log(`${counter.actions.decrement}`)
// // -> "counter/decrement"
// store.dispatch(user.actions.setUserName('eric'))
// // -> { counter: 12, user: { name: 'eric', age: 22} }