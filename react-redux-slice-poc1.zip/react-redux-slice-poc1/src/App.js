import './App.css';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect, useState } from 'react';
import {increment,decrement,multiply} from './store';
function App() {
  const {name,age} = useSelector(state => state.userSlice);
  const dispatch = useDispatch();
  const {counter}= useSelector(state => state.counterSlice);


  async function fetchInterceptor(response) {
    let data = await response.json();
    const {status} = await response;
    console.log('<= server status => ',status)
    let statusCode = 200;
    let message = "Success";

    switch(status){
      case 200:
        statusCode = 200;
        message = "Success";
        break;

      case 201:
        statusCode = 201;
        message = "Created";
        break;
      
      case 204:
        statusCode = 204;
        message = "Ok";
        break;

      case 300:
        statusCode = 300;
        message = "Redirection";
        break;

      case 400:
        statusCode = 400;
        message = "Client side Error";
        break;

      case 404:
        statusCode = 404;
        message = "Client side Error";
        break;

      case 401:
        statusCode = 401;
        message = "UnAuthorized";
        break;
      
      case 403:
        statusCode = 403;
        message = "Forbidden";
        break;

      case 500:
        statusCode = 500;
        message = "Server error";
          break;

      default:
        statusCode = 500;
        message = "Somethingk went wrong";
          break;
    }
    data = response.ok ? data : null;
    return {statusCode, message, data};
  }

  async function fetchData() {
    try{
      const resp = await fetch("https://jsonplaceholder.typicode.com/todos/1/adfa");
      const {statusCode,message,data} = await fetchInterceptor(resp);
      console.log("statusCode ",statusCode, " message " ,message , " data ",data);
    }catch(err){
        console.log("error ",err);
    }
  }

  useEffect(() => {
    fetchData();
  });
  useEffect(()=>{
    console.log("username => "+name+'age '+age+" counter "+counter);
  },[]);
  const inc = () =>{
    dispatch(increment());
  }
  const dec = () =>{
    dispatch(decrement());
  }
  return (
    <div className="App">
      <label>{counter}</label>
      <button onClick={inc}>Increment</button>
      <button onClick={dec}>Decrement</button>

      <label>{name}{age}</label>
    </div>
  );
}

export default App;
